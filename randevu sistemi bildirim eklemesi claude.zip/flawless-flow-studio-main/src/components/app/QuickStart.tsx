import { useEffect, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { Play, Timer } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FormDrawer } from "@/components/app/forms/FormDrawer";
import { useMe } from "@/hooks/use-me";
import { useCustomers } from "@/lib/data";
import { todayISO } from "@/lib/finance";
import { getPosition, type Coords } from "@/lib/geo";
import { elapsedSeconds, useRecords, useSaveRecord } from "@/lib/work";

const hms = (s: number) => [s / 3600, (s % 3600) / 60, s % 60].map((n) => String(Math.floor(n)).padStart(2, "0")).join(":");

/** Panelin en üstünde: tek dokunuşla müşteri seç → kronometre + GPS konumu ile işi başlat. */
export function QuickStart() {
  const customers = useCustomers();
  const jobs = useRecords("job");
  const save = useSaveRecord("job");
  const me = useMe();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [customerId, setCustomerId] = useState("");
  const [title, setTitle] = useState("");
  const [now, setNow] = useState(Date.now());
  const running = (jobs.data ?? []).filter((j) => j.payload.started_at && !j.payload.billed);

  useEffect(() => {
    if (!running.length) return;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [running.length]);

  async function start() {
    const c = (customers.data ?? []).find((x) => x.id === customerId);
    let pos: Coords | null = null;
    try { pos = await getPosition(4000); } catch { /* konum olmadan da başlar */ }
    try {
      await save.mutateAsync({
        owner_id: me.data?.id,
        payload: {
          title: title.trim() || (c ? `${c.name} işi` : "Saha işi"),
          customer_id: c?.id ?? null, address: c?.address ?? "", date: todayISO(),
          status: "Devam Ediyor", seconds: 0, started_at: new Date().toISOString(), vat_rate: 0,
          lat: pos?.lat ?? null, lng: pos?.lng ?? null,
        },
      });
      setOpen(false); setTitle(""); setCustomerId("");
      void navigate({ to: "/isler" });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "İş başlatılamadı");
    }
  }

  return (
    <>
      <Button className="h-24 w-full rounded-2xl text-2xl font-bold shadow-lg" onClick={() => setOpen(true)}>
        <Play className="size-8" />
        İşe Başla
      </Button>
      {running.map((j) => (
        <Link key={j.id} to="/isler" className="flex items-center justify-between rounded-2xl border border-primary/40 bg-primary/10 p-4">
          <div className="min-w-0">
            <p className="truncate font-semibold">{String(j.payload.title)}</p>
            <p className="text-xs text-muted-foreground">Devam eden iş</p>
          </div>
          <span className="num flex items-center gap-2 text-xl"><Timer className="size-5" />{hms(elapsedSeconds(j.payload, now))}</span>
        </Link>
      ))}
      <FormDrawer open={open} onOpenChange={setOpen} title="İşe başla" submitLabel="Kronometreyi başlat" busy={save.isPending} onSubmit={() => void start()}>
        <div className="space-y-2">
          <Label htmlFor="qs-customer">Müşteri</Label>
          <select id="qs-customer" className="h-12 w-full rounded-md border bg-secondary px-3" value={customerId} onChange={(e) => setCustomerId(e.target.value)}>
            <option value="">Müşteri seçmeden başla</option>
            {(customers.data ?? []).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="qs-title">İş adı (isteğe bağlı)</Label>
          <Input id="qs-title" className="h-12" value={title} onChange={(e) => setTitle(e.target.value)} />
        </div>
        <p className="text-xs text-muted-foreground">Başlarken mevcut GPS konumunuz işe kaydedilir.</p>
      </FormDrawer>
    </>
  );
}
