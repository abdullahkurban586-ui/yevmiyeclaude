import { AlertTriangle, Wrench } from "lucide-react";
import { maintenanceStatus, type WorkRecord } from "@/lib/work";

/** Seçilen makinenin bakım durumunu (yeşil/sarı/kırmızı) ve aynı gün çakışmasını gösterir. */
export function MachineInfo({ equipment, id, jobSeconds = 0, date, jobs = [], selfId }: {
  equipment: WorkRecord[]; id: string; jobSeconds?: number; date?: string; jobs?: WorkRecord[]; selfId?: string | undefined;
}) {
  const eq = equipment.find((e) => e.id === id);
  if (!eq) return null;
  const m = maintenanceStatus(eq.payload, Date.now(), jobSeconds);
  const clash = date ? jobs.filter((j) => j.id !== selfId && j.payload.equipment_id === id && j.payload.date === date && !j.payload.billed).length : 0;
  const tone = m.level === "over" ? "border-destructive/50 bg-destructive/10 text-destructive" : m.level === "warn" ? "border-warning/50 bg-warning/10 text-warning" : "bg-secondary text-muted-foreground";
  return (
    <div className="space-y-1">
      <div className={"flex items-center gap-2 rounded-lg border p-2 text-xs " + tone}>
        <Wrench className="size-4 shrink-0" />
        <span className="min-w-0 flex-1">
          <b>{String(eq.payload.name)}</b> · {m.used.toFixed(1)}/{m.interval} saat ·{" "}
          {m.level === "over" ? `Bakım zamanı GEÇTİ (${(-m.remaining).toFixed(1)} sa)` : m.level === "warn" ? `Bakım zamanı yaklaştı (${m.remaining.toFixed(1)} sa kaldı)` : `Bakıma ${m.remaining.toFixed(1)} sa var`}
        </span>
      </div>
      {clash > 0 && (
        <p className="flex items-center gap-1 text-xs text-warning"><AlertTriangle className="size-3" /> Bu makine aynı gün {clash} başka işte de görünüyor.</p>
      )}
    </div>
  );
}
