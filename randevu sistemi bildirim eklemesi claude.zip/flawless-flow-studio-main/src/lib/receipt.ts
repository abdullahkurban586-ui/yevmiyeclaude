import type { Customer } from "@/lib/data";
import { formatDate, formatTL, profitBreakdown, type Tx } from "@/lib/finance";

let fontCache: { regular: string; bold: string } | null = null;

async function toBase64(url: string) {
  const buf = await (await fetch(url)).arrayBuffer();
  let binary = "";
  const bytes = new Uint8Array(buf);
  for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(binary);
}

const ONES = ["", "bir", "iki", "üç", "dört", "beş", "altı", "yedi", "sekiz", "dokuz"];
const TENS = ["", "on", "yirmi", "otuz", "kırk", "elli", "altmış", "yetmiş", "seksen", "doksan"];
function trWords(n: number): string {
  if (n === 0) return "sıfır";
  const grp = (x: number) => {
    const h = Math.floor(x / 100), t = Math.floor((x % 100) / 10), o = x % 10;
    return [h ? (h > 1 ? ONES[h] + " " : "") + "yüz" : "", TENS[t], ONES[o]].filter(Boolean).join(" ");
  };
  const m = Math.floor(n / 1_000_000), th = Math.floor((n % 1_000_000) / 1000), r = n % 1000;
  return [m ? grp(m) + " milyon" : "", th ? (th === 1 ? "" : grp(th) + " ") + "bin" : "", r ? grp(r) : ""].filter(Boolean).join(" ");
}
export function amountInWords(v: number) {
  const lira = Math.floor(v), kurus = Math.round((v - lira) * 100);
  const cap = (x: string) => x.split(" ").map((w) => w.charAt(0).toLocaleUpperCase("tr-TR") + w.slice(1)).join(" ");
  return `Yalnız ${cap(trWords(lira))} Türk Lirası${kurus ? " " + cap(trWords(kurus)) + " Kuruştur" : "dır"}.`;
}

export interface BusinessProfile {
  business?: string | number | boolean | null;
  address?: string | number | boolean | null;
  phone?: string | number | boolean | null;
  tax?: string | number | boolean | null;
  iban?: string | number | boolean | null;
}

/** Resmi görünümlü A4 makbuz (iş borcu ya da tahsilat). */
export async function buildReceipt(opts: { business?: string; profile?: BusinessProfile; customer: Customer; tx: Tx; balance: number }) {
  const { customer, tx, balance } = opts;
  const prof = opts.profile ?? {};
  const business = String(prof.business ?? opts.business ?? "Saha");
  const { jsPDF } = await import("jspdf");
  if (!fontCache) {
    const [regular, bold] = await Promise.all([toBase64("/fonts/DejaVuSans.ttf"), toBase64("/fonts/DejaVuSans-Bold.ttf")]);
    fontCache = { regular, bold };
  }
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  doc.addFileToVFS("DejaVu.ttf", fontCache.regular);
  doc.addFont("DejaVu.ttf", "DejaVu", "normal");
  doc.addFileToVFS("DejaVu-Bold.ttf", fontCache.bold);
  doc.addFont("DejaVu-Bold.ttf", "DejaVu", "bold");

  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const M = 15;
  const isDebt = tx.kind === "debt";
  const no = `MKB-${tx.occurred_on.slice(0, 4)}-${tx.id.slice(0, 6).toUpperCase()}`;
  const NAVY: [number, number, number] = [23, 37, 62];
  const GREY: [number, number, number] = [110, 110, 110];
  const font = (bold = false, size = 9, color: [number, number, number] = [30, 30, 30]) => {
    doc.setFont("DejaVu", bold ? "bold" : "normal");
    doc.setFontSize(size);
    doc.setTextColor(...color);
  };

  // Başlık bandı
  doc.setFillColor(...NAVY);
  doc.rect(0, 0, W, 36, "F");
  font(true, 18, [255, 255, 255]);
  doc.text(business, M, 15);
  font(false, 8.5, [200, 208, 222]);
  const meta = [prof.address, prof.phone ? `Tel: ${prof.phone}` : "", prof.tax ? `Vergi: ${prof.tax}` : ""].filter(Boolean).map(String);
  meta.forEach((l, i) => doc.text(doc.splitTextToSize(l, 105)[0] as string, M, 22 + i * 4.5));
  font(true, 14, [255, 255, 255]);
  doc.text(isDebt ? "İŞ MAKBUZU" : "TAHSİLAT MAKBUZU", W - M, 15, { align: "right" });
  font(false, 8.5, [200, 208, 222]);
  doc.text(`Makbuz No: ${no}`, W - M, 22, { align: "right" });
  doc.text(`Tarih: ${formatDate(tx.occurred_on)}`, W - M, 26.5, { align: "right" });

  // Müşteri kutusu
  let y = 46;
  doc.setDrawColor(210, 214, 222);
  doc.setFillColor(247, 248, 250);
  doc.roundedRect(M, y, W - 2 * M, 28, 2, 2, "FD");
  font(true, 7.5, GREY);
  doc.text("SAYIN", M + 5, y + 7);
  font(true, 12);
  doc.text(customer.name, M + 5, y + 14);
  font(false, 9, GREY);
  if (customer.phone) doc.text(`Tel: ${customer.phone}`, M + 5, y + 20);
  if (customer.address) doc.text(doc.splitTextToSize(customer.address, W - 2 * M - 10).slice(0, 1) as string[], M + 5, y + 25);

  // Kalem tablosu
  y += 38;
  doc.setFillColor(...NAVY);
  doc.rect(M, y, W - 2 * M, 8, "F");
  font(true, 8.5, [255, 255, 255]);
  doc.text("AÇIKLAMA", M + 3, y + 5.5);
  doc.text("TUTAR", W - M - 3, y + 5.5, { align: "right" });
  y += 8;
  const line = (label: string, value: string, bold = false, shade = false) => {
    if (shade) { doc.setFillColor(247, 248, 250); doc.rect(M, y, W - 2 * M, 8, "F"); }
    font(bold, 9.5);
    doc.text(label, M + 3, y + 5.5);
    doc.text(value, W - M - 3, y + 5.5, { align: "right" });
    doc.setDrawColor(228, 231, 237);
    doc.line(M, y + 8, W - M, y + 8);
    y += 8;
  };
  let total = tx.amount;
  if (isDebt) {
    const pb = profitBreakdown(tx.amount, tx.material_cost, tx.vat_rate);
    const desc = tx.description?.trim() || "Hizmet bedeli";
    const lines = doc.splitTextToSize(desc, W - 2 * M - 50) as string[];
    font(false, 9.5);
    doc.text(lines, M + 3, y + 5.5);
    doc.line(M, y + lines.length * 5 + 3, W - M, y + lines.length * 5 + 3);
    y += lines.length * 5 + 3;
    if (tx.material_cost > 0) line("Malzeme", formatTL(tx.material_cost));
    line("İşçilik / Hizmet", formatTL(Math.max(0, pb.netOfVat - tx.material_cost)), false, true);
    line("Ara toplam (KDV hariç)", formatTL(pb.netOfVat));
    if (tx.vat_rate > 0) line(`KDV (%${tx.vat_rate})`, formatTL(pb.vat), false, true);
    total = tx.amount;
  } else {
    line(tx.description?.trim() || "Tahsilat", formatTL(tx.amount));
    line("Ödeme yöntemi", String(tx.method ?? "Nakit"), false, true);
  }

  // Genel toplam + yazıyla
  y += 4;
  doc.setFillColor(...NAVY);
  doc.rect(W - M - 80, y, 80, 11, "F");
  font(true, 10, [255, 255, 255]);
  doc.text(isDebt ? "GENEL TOPLAM" : "TAHSİL EDİLEN", W - M - 77, y + 7.2);
  doc.text(formatTL(total), W - M - 3, y + 7.2, { align: "right" });
  font(false, 8.5, GREY);
  doc.text(doc.splitTextToSize(amountInWords(total), W - 2 * M - 88) as string[], M, y + 5);
  y += 20;

  // Hesap özeti
  font(true, 8, GREY);
  doc.text("CARİ HESAP ÖZETİ", M, y);
  y += 3;
  doc.setDrawColor(210, 214, 222);
  doc.roundedRect(M, y, W - 2 * M, 16, 2, 2, "S");
  font(false, 9.5);
  doc.text(isDebt ? "Bu işlemle hesaba işlenen borç" : "Bu işlemle hesaptan düşülen ödeme", M + 5, y + 6.5);
  doc.text(formatTL(tx.amount), W - M - 5, y + 6.5, { align: "right" });
  font(true, 10.5, balance > 0 ? [180, 40, 40] : [30, 120, 60]);
  doc.text(balance > 0 ? "Kalan bakiye (borç)" : "Kalan bakiye", M + 5, y + 12.5);
  doc.text(formatTL(balance), W - M - 5, y + 12.5, { align: "right" });
  y += 26;

  // Ödeme bilgisi
  if (prof.iban && balance > 0) {
    font(true, 8, GREY);
    doc.text("ÖDEME BİLGİSİ", M, y);
    font(false, 9.5);
    doc.text(`IBAN: ${prof.iban}`, M, y + 6);
    doc.text(`Alıcı: ${business}`, M, y + 11.5);
    y += 20;
  }

  // İmza alanları
  const sy = Math.max(y + 10, H - 62);
  doc.setDrawColor(150, 150, 150);
  doc.line(M, sy + 18, M + 65, sy + 18);
  doc.line(W - M - 65, sy + 18, W - M, sy + 18);
  font(true, 8.5);
  doc.text(isDebt ? "Teslim Eden" : "Tahsil Eden", M + 32.5, sy + 23, { align: "center" });
  doc.text(isDebt ? "Teslim Alan" : "Ödeme Yapan", W - M - 32.5, sy + 23, { align: "center" });
  font(false, 8, GREY);
  doc.text(business, M + 32.5, sy + 27.5, { align: "center" });
  doc.text(customer.name, W - M - 32.5, sy + 27.5, { align: "center" });

  // Alt bilgi
  doc.setDrawColor(210, 214, 222);
  doc.line(M, H - 16, W - M, H - 16);
  font(false, 7.5, GREY);
  doc.text("Bu belge bilgi amaçlı makbuzdur; mali belge (fatura/fiş) yerine geçmez.", W / 2, H - 11, { align: "center" });
  doc.text(`${business} · Teşekkür ederiz · ${no}`, W / 2, H - 7, { align: "center" });

  const blob = doc.output("blob");
  return new File([blob], `makbuz-${no}.pdf`, { type: "application/pdf" });
}

export async function shareOrDownload(file: File) {
  const nav = navigator as Navigator & { canShare?: (d: { files: File[] }) => boolean };
  if (nav.canShare?.({ files: [file] })) {
    try {
      await nav.share({ files: [file], title: file.name });
      return;
    } catch (e) {
      if ((e as Error).name === "AbortError") return;
    }
  }
  const url = URL.createObjectURL(file);
  const a = document.createElement("a");
  a.href = url;
  a.download = file.name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}
