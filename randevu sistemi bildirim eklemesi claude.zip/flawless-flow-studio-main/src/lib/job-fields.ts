import { useEffect, useState } from "react";
import type { Field } from "@/components/app/RecordFields";
import type { Customer } from "@/lib/data";
import type { WorkRecord } from "@/lib/work";
import { supabase } from "@/integrations/supabase/client";

export type Member = { id: string; username: string };

export function useMembers() {
  const [members, setMembers] = useState<Member[]>([]);
  useEffect(() => {
    supabase.from("profiles").select("id,username").then(({ data }) => setMembers(data ?? []));
  }, []);
  return members;
}

/** "İş ekle" formunun alanları; İşler ve Randevu sayfaları ortak kullanır. */
export function jobFields(customers: Customer[], members: Member[], equipment: WorkRecord[] = []): Field[] {
  return [
    // Makine ile yapılacak işlerde ilk önce makine seçilir; iş süresi makinenin bakım sayacına eklenir.
    { key: "equipment_id", label: "Kullanılacak makine (makinesiz ise boş bırakın)", options: equipment.map((e) => ({ value: e.id, label: String(e.payload.name) })) },
    { key: "title", label: "İş adı", required: true },
    { key: "customer_id", label: "Müşteri", options: customers.map((c) => ({ value: c.id, label: c.name })) },
    { key: "owner_id", label: "Görevli", options: members.map((m) => ({ value: m.id, label: m.username })) },
    { key: "date", label: "Randevu tarihi", type: "date", required: true },
    { key: "address", label: "İş adresi" },
    { key: "hourly_rate", label: "Saatlik ücret (TL)", type: "number" },
    { key: "price", label: "Sabit iş ücreti (TL)", type: "number" },
    { key: "material_cost", label: "Malzeme maliyeti (TL)", type: "number" },
    {
      key: "vat_rate",
      label: "KDV",
      options: [
        { value: "0", label: "Yok" },
        { value: "10", label: "%10" },
        { value: "20", label: "%20" },
      ],
    },
    { key: "notes", label: "İş notu" },
  ];
}
