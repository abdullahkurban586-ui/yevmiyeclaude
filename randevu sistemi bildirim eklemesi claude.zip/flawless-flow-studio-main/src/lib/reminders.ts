import { useEffect } from "react";
import { toast } from "sonner";
import { useRecords, type Payload } from "@/lib/work";

export const REMIND_OPTIONS = [
  { value: "0", label: "Tam zamanında" },
  { value: "10", label: "10 dk önce" },
  { value: "30", label: "30 dk önce" },
  { value: "60", label: "1 saat önce" },
  { value: "1440", label: "1 gün önce" },
];

export const apptStart = (p: Payload) => Date.parse(`${p.date}T${p.time || "09:00"}:00`);

export const notifySupported = () => typeof window !== "undefined" && "Notification" in window;

export async function askNotifyPermission() {
  if (!notifySupported()) return "denied" as const;
  return Notification.requestPermission();
}

async function show(title: string, body: string, tag: string) {
  if (!notifySupported() || Notification.permission !== "granted") return;
  const opts = { body, tag, icon: "/icon-192.png", data: { url: "/randevu" }, vibrate: [200, 100, 200] } as NotificationOptions;
  try {
    const reg = await navigator.serviceWorker?.getRegistration();
    if (reg) return void (await reg.showNotification(title, opts));
    const n = new Notification(title, opts);
    n.onclick = () => { window.focus(); location.assign("/randevu"); };
  } catch { /* bildirim gösterilemedi; uygulama içi uyarı yine çıkar */ }
}

const seen = (k: string) => { try { return localStorage.getItem(k) === "1"; } catch { return false; } };
const mark = (k: string) => { try { localStorage.setItem(k, "1"); } catch { /* yok say */ } };

/** Uygulama açıkken (veya arka plandayken) 30 sn'de bir randevuları kontrol eder. */
export function useAppointmentReminders(enabled: boolean, onOpen: () => void) {
  const recs = useRecords("appointment");
  useEffect(() => {
    if (!enabled) return;
    const tick = () => {
      const now = Date.now();
      for (const r of recs.data ?? []) {
        if (r.payload.status !== "Bekliyor" || r.payload.archived) continue;
        const start = apptStart(r.payload);
        if (!Number.isFinite(start) || now > start + 2 * 3600_000) continue;
        const lead = Number(r.payload.remind ?? 30) * 60_000;
        const name = String(r.payload.name);
        const at = String(r.payload.time ?? "");
        const stages: [string, boolean, string, string][] = [
          [`pre:${lead}`, lead > 0 && now >= start - lead && now < start, "Randevu yaklaşıyor", `${name} · saat ${at}`],
          ["now", now >= start, "Randevu zamanı geldi", `${name} · işi başlatabilirsiniz`],
        ];
        for (const [stage, due, title, body] of stages) {
          const key = `ap:${r.id}:${r.payload.date}${r.payload.time}:${stage}`;
          if (!due || seen(key)) continue;
          mark(key);
          void show(title, body, key);
          toast(`${title}: ${name}`, { description: at, duration: 15000, action: { label: "Aç", onClick: onOpen } });
        }
      }
    };
    tick();
    const t = setInterval(tick, 30_000);
    document.addEventListener("visibilitychange", tick);
    return () => { clearInterval(t); document.removeEventListener("visibilitychange", tick); };
  }, [enabled, recs.data, onOpen]);
}
