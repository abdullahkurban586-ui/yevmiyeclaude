-- İş bitirilip cariye işlendiğinde, işte kullanılan makinenin toplam çalışma sayacına (payload.seconds)
-- iş süresi atomik olarak eklenir. bill_job zaten idempotent olduğundan çift sayım olmaz.
CREATE OR REPLACE FUNCTION public.bill_job(_job_id uuid) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE j public.work_records; c public.customers; result uuid; seconds numeric; amount numeric; eq_id uuid;
BEGIN
 IF NOT public.is_team_usta() THEN RAISE EXCEPTION 'Yetkisiz'; END IF;
 SELECT * INTO j FROM public.work_records WHERE id=_job_id AND team_id=public.current_team() AND kind='job' FOR UPDATE;
 IF j.id IS NULL THEN RAISE EXCEPTION 'İş bulunamadı'; END IF;
 SELECT id INTO result FROM public.transactions WHERE job_record_id=j.id;
 IF result IS NOT NULL THEN RETURN result; END IF;
 SELECT * INTO c FROM public.customers WHERE id=(j.payload->>'customer_id')::uuid AND team_id=public.current_team();
 IF c.id IS NULL THEN RAISE EXCEPTION 'Müşteri seçin'; END IF;
 seconds:=coalesce((j.payload->>'seconds')::numeric,0);
 IF j.payload->>'started_at' IS NOT NULL THEN seconds:=seconds+greatest(0,extract(epoch FROM now()-(j.payload->>'started_at')::timestamptz)); END IF;
 amount:=CASE WHEN coalesce((j.payload->>'hourly_rate')::numeric,0)>0 THEN round(seconds/3600*(j.payload->>'hourly_rate')::numeric,2) ELSE coalesce((j.payload->>'price')::numeric,0) END;
 IF amount<=0 THEN RAISE EXCEPTION 'İş tutarı sıfır olamaz'; END IF;
 INSERT INTO public.transactions(customer_id,kind,amount,description,material_cost,vat_rate,job_record_id) VALUES(c.id,'debt',amount,j.payload->>'title',coalesce((j.payload->>'material_cost')::numeric,0),coalesce((j.payload->>'vat_rate')::smallint,0),j.id) RETURNING id INTO result;
 -- Makine sayacı (kestirimci bakım)
 IF coalesce(j.payload->>'equipment_id','')<>'' THEN
  eq_id:=(j.payload->>'equipment_id')::uuid;
  UPDATE public.work_records SET payload=jsonb_set(payload,'{seconds}',to_jsonb(coalesce((payload->>'seconds')::numeric,0)+seconds)),updated_at=now()
   WHERE id=eq_id AND team_id=j.team_id AND kind='equipment';
 END IF;
 UPDATE public.work_records SET payload=payload||jsonb_build_object('status','Tamamlandı','seconds',seconds,'started_at',null,'billed',true),updated_at=now() WHERE id=j.id;
 RETURN result;
END; $$;
REVOKE ALL ON FUNCTION public.bill_job(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.bill_job(uuid) TO authenticated,service_role;
